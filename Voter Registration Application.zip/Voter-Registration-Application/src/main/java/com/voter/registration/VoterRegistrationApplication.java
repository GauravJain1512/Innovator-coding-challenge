package com.voter.registration;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VoterRegistrationApplication {

	public static void main(String[] args) {
		SpringApplication.run(VoterRegistrationApplication.class, args);
	}

}
