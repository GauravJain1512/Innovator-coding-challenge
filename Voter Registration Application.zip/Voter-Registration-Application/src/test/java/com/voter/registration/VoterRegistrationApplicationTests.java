package com.voter.registration;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VoterRegistrationApplicationTests {

	@Test
	void contextLoads() {
	}

}
